Spider Scientific V2 — Strengthened Production-Style Stack

Improvements added:
- Modular backend structure:
  routes/
  services/
  scoring/
  utils/
- MyGene, STRING, Reactome and QuickGO separated into service files.
- Persistent JSON disk cache in backend/cache.
- API status reporting for every source.
- Evidence trail for each gene.
- Evidence-weighted category scoring using Reactome + QuickGO + curated rules.
- GWAS/gene-list upload endpoint: POST /api/gwas.
- Frontend GWAS/gene-list panel.
- Export JSON.
- Save project to browser localStorage.
- Browser print/export-image helper.
- Smoke tests.

Run locally:
1. cd backend
2. npm install
3. npm start
4. Open frontend/index.html

Test backend:
- http://localhost:3000
- http://localhost:3000/api/gene/TP53
- http://localhost:3000/api/search?q=TGF

Deploy on Render:
1. Upload full folder to GitHub.
2. Backend: New Web Service
   Root Directory: backend
   Build Command: npm install
   Start Command: npm start
3. Copy backend URL.
4. In frontend/app.js replace API_BASE with the backend URL.
5. Frontend: New Static Site
   Root Directory: frontend
   Publish Directory: .

Important:
Fallback data is clearly marked. For a scientific product, avoid presenting fallback data as real evidence.
