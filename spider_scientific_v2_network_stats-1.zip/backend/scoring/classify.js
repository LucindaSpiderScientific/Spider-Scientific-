const { norm } = require("../utils/norm");

const categoryTerms = {
  signaling: ["signaling","signal transduction","receptor","kinase","phosphorylation","smad","mapk","tgf-beta","jak","stat","pi3k","akt","ras","raf","erk"],
  matrix: ["extracellular matrix","collagen","adhesion","integrin","matrix","laminin","fibronectin","basement membrane","metalloproteinase"],
  immune: ["immune","cytokine","inflammatory","inflammation","leukocyte","lymphocyte","t cell","b cell","macrophage","interleukin","chemokine","interferon"],
  development: ["development","morphogenesis","differentiation","organogenesis","embryo","patterning","cell fate","developmental process"],
  growth: ["growth","proliferation","cell cycle","apoptosis","apoptotic","cell death","survival","senescence","tumor","cancer"],
  metabolism: ["metabolic","metabolism","glucose","lipid","insulin","transport","biosynthetic","catabolic","mitochondrial"]
};

const evidenceWeights = { EXP:7, IDA:7, IPI:6, IMP:6, IGI:6, IEP:5, TAS:4, IC:4, ISS:3, ISO:3, ISA:3, IEA:1, NAS:2, ND:.5 };

function classify(symbol, meta, reactome, quickgo){
  const scores = { signaling:0, matrix:0, immune:0, development:0, growth:0, metabolism:0 };
  const evidenceByCategory = { signaling:[], matrix:[], immune:[], development:[], growth:[], metabolism:[] };

  const add = (cat, points, evidence) => {
    scores[cat] += points;
    evidenceByCategory[cat].push(evidence);
  };

  const sources = [
    ...reactome.map(x => ({ source:"Reactome", text:x.name, url:x.url, weight:6 })),
    ...quickgo.map(x => ({ source:"QuickGO", text:x.name, url:x.url, weight:evidenceWeights[x.evidenceCode] || 2, evidenceCode:x.evidenceCode })),
    { source:"MyGene", text:meta?.summary || "", url:"https://mygene.info", weight:1.5 }
  ];

  for(const src of sources){
    const text = String(src.text || "").toLowerCase();
    for(const [cat, terms] of Object.entries(categoryTerms)){
      for(const term of terms){
        if(text.includes(term)){
          add(cat, src.weight, {
            source:src.source,
            label:src.text,
            match:term,
            weight:src.weight,
            evidenceCode:src.evidenceCode || "",
            url:src.url || ""
          });
        }
      }
    }
  }

  const sym = norm(symbol);
  const curatedRules = [
    [/^TGFB|^TGFBR|^SMAD|^BMP/, [["signaling",8],["development",5],["immune",5],["growth",4]], "Curated TGFB/BMP/SMAD family rule"],
    [/FOXP3|IL10|IL6|TNF|CTLA4|PDCD1|CD4|CD8|IFNG|STAT/, [["immune",6]], "Curated immune marker rule"],
    [/LTBP|DCN|ITGA|ITGB|COL|FBN|LAMA|FN1|BGN|ELN|MMP|TIMP/, [["matrix",6]], "Curated ECM/matrix marker rule"],
    [/TP53|MYC|CDK|CDKN|CCND|BCL|CASP|MDM2|ATM|CHEK/, [["growth",6]], "Curated growth/cell-cycle marker rule"],
    [/SOX|PAX|GATA|RUNX|TBX|NKX|HOX|WNT|BMP/, [["development",5]], "Curated development marker rule"],
    [/AKT|MTOR|PIK3|SLC|PPAR|LDH|HK|INSR|SIRT/, [["metabolism",4]], "Curated metabolism marker rule"]
  ];

  curatedRules.forEach(([regex, cats, label]) => {
    if(regex.test(sym)){
      cats.forEach(([cat, points]) => add(cat, points, {
        source:"Spider Scientific rule",
        label,
        match:sym,
        weight:points,
        url:""
      }));
    }
  });

  const sorted = Object.entries(scores).filter(([,v]) => v > 0).sort((a,b) => b[1]-a[1]);
  const primary = sorted[0]?.[0] || "signaling";
  const top = sorted[0]?.[1] || 1;
  const secondary = sorted.slice(1).filter(([,v]) => v >= Math.max(4, top * 0.42)).map(([k]) => k).slice(0,4);

  return { primary, secondary, scores, evidenceByCategory };
}

module.exports = { classify, evidenceWeights };