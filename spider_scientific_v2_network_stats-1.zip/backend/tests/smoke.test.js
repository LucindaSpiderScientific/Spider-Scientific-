const { norm } = require("../utils/norm");
const { classify } = require("../scoring/classify");

function assert(condition, message){
  if(!condition){
    console.error("FAIL:", message);
    process.exit(1);
  }
}

assert(norm(" tp53 ") === "TP53", "norm should uppercase and trim");

const tgfb = classify("TGFB1", {summary:"cytokine signaling immune growth development"}, [], []);
assert(tgfb.primary, "classification returns primary category");
assert(tgfb.secondary.length >= 1, "TGFB1 should have cross-context categories");

console.log("Smoke tests passed");