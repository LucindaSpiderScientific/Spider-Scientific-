const fs = require("fs");
const path = require("path");

const CACHE_DIR = path.join(__dirname, "..", "cache");
const MEMORY = new Map();

function safeName(url){
  return Buffer.from(url).toString("base64url") + ".json";
}

async function fetchJSON(url, options = {}, fallback = null, source = "unknown"){
  const file = path.join(CACHE_DIR, safeName(url));

  if(MEMORY.has(url)){
    return { ok:true, source, cached:true, data:MEMORY.get(url), status:"memory-cache" };
  }

  if(fs.existsSync(file)){
    try{
      const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
      MEMORY.set(url, parsed);
      return { ok:true, source, cached:true, data:parsed, status:"disk-cache" };
    }catch(e){}
  }

  try{
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 14000);
    const r = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timer);

    if(!r.ok){
      return { ok:false, source, cached:false, data:fallback, status:`HTTP ${r.status}` };
    }

    const data = await r.json();
    MEMORY.set(url, data);
    try{ fs.writeFileSync(file, JSON.stringify(data)); }catch(e){}
    return { ok:true, source, cached:false, data, status:"live" };
  }catch(err){
    return { ok:false, source, cached:false, data:fallback, status:err.message || "request failed" };
  }
}

module.exports = { fetchJSON };