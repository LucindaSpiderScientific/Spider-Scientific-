function norm(x){ return String(x || "").trim().toUpperCase(); }
module.exports = { norm };